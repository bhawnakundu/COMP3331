 import java.io.*;
import java.net.*;
import java.util.*;
import java.util.Collections;

public class PingClient {

        public static ArrayList <Long> timeList = new ArrayList<Long>();

        public static void main(String[] args) throws Exception
        {
                if (args.length != 2) {
                    System.out.println("Required arguments: host port");
                        return;
                }

                int orgPort = Integer.parseInt(args[1]);
                InetAddress server = InetAddress.getByName(args[0]);
                DatagramSocket skt = new DatagramSocket(8765);

                    int traverser = 0;
                    String orgHost = args[0];

                    while (traverser < 10) {
                        long sendTime = System.currentTimeMillis();
                        String line = "ping to " + orgHost + ", " + "seq = "+ traverser + ", \n";
                        byte[] buf = new byte[1024];
                        buf = line.getBytes();
                        DatagramPacket ping = new DatagramPacket(buf, buf.length, server, orgPort);
                        skt.send(ping);
                        try {
                                skt.setSoTimeout(1000);   
                                DatagramPacket receivedPackets = new DatagramPacket(new byte[1024], 1024);
                                skt.receive(receivedPackets);
                                long receiveTime = System.currentTimeMillis();
                                printData(receivedPackets, receiveTime-sendTime);
                                timeList.add(receiveTime-sendTime);
                        }
                        catch(IOException e){
                                 System.out.println("ping to " + args[0] + ", " +"seq = "+ traverser +", time out");
                        }
                        traverser++;
                    }
                    System.out.println("Minimum time: " + Collections.min(timeList)+ " ms" +" | "+ "Maximum time: " + Collections.max(timeList)+ " ms" + " | " + "Average time: " + average(timeList)+ " ms");
                   }

                   private static void printData(DatagramPacket packet, long time) throws Exception
                   {
                        byte[] buf = packet.getData();
                        ByteArrayInputStream bais = new ByteArrayInputStream(buf);
                        InputStreamReader isr = new InputStreamReader(bais);
                        BufferedReader br = new BufferedReader(isr);
                        String line = br.readLine();
                        System.out.println(new String(line) + "rtt: " + time + " ms");
                    }

                    private static long average( ArrayList<Long> time) {
                         Long sum = 0L;
                         if(!time.isEmpty()) {
                                for (Long times : time) {
                                        sum += times;
                                 }
                                 return sum.longValue() / time.size();
                                 }
                        return sum;
                    }
                }

